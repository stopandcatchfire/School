package com.mycompany.a3;

import com.codename1.ui.geom.Dimension;

public interface IMovable {

	public void move(Dimension d);
	
}
