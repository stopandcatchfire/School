package com.mycompany.a3;

public interface ISelectable {

	
	public boolean getSelected();
	public void setSelected(boolean b);
}
